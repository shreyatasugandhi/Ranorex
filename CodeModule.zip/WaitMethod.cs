﻿/*
 * Created by Ranorex
 * User: alkasugandhi_ss
 * Date: 4/2/2019
 * Time: 7:21 AM
 * 
 * To change this template use Tools > Options > Coding > Edit standard headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

namespace RxApp
{
    /// <summary>
    /// Description of WaitMethod.
    /// </summary>
    [TestModule("7D189CC9-C7B3-488E-A435-B7B6680F180C", ModuleType.UserCode, 1)]
    public class WaitMethod : ITestModule
    {
        /// <summary>
        /// Constructs a new instance.
        /// </summary>
        public WaitMethod()
        {
            // Do not delete - a parameterless constructor is required!
        }

        /// <summary>
        /// Performs the playback of actions in this module.
        /// </summary>
        /// <remarks>You should not call this method directly, instead pass the module
        /// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
        /// that will in turn invoke this method.</remarks>
        void ITestModule.Run()
        {
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;
            
            // Use the 'Info' object to check existence of the
			// 'SaveDialog' item; Method 'Exists' uses the timeout
			// specified for the 'SaveDialog' in the repository
			Report.Info("Exists = " + repo.SaveDialog.SelfInfo.Exists().ToString());
			
			
			// Use the 'Info' object to check existence of the
			// 'TextOnline' item which uses the following RXPath:
			// statusbar/text[@accessiblename='Online']
			// This way you can wait with the timeout specified for
			// the item within the repository for the text 'Online'
			bool statusTextConnected = repo.AUT.TextOnlineInfo.Exists();
			
			// Using 'Info' objects for validation
			// Throws a Ranorex.ValidationException if validation
			// fails. Automatically reports success or failed message
			// to log file
			Validate.Exists(repo.SaveDialog.ButtonOKInfo);
			
			
			// Validates the existence of the repository item,
			// but does not throw any exception
			Validate.Exists(repo.SaveDialog.ButtonOKInfo,"Check Object '{0}'",false);
        }
    }
}
