﻿/*
 * Created by Ranorex
 * User: alkasugandhi_ss
 * Date: 4/2/2019
 * Time: 6:50 AM
 * 
 * To change this template use Tools > Options > Coding > Edit standard headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

namespace RxApp
{
    /// <summary>
    /// Description of WorkingWithRepo.
    /// </summary>
    [TestModule("671B31EA-97A8-44DB-8641-4776B2F29B29", ModuleType.UserCode, 1)]
    public class WorkingWithRepo : ITestModule
    {
        // Repository object to access UI elements
		RxAppRepository repo = RxAppRepository.Instance;
		/// <summary>
		/// Constructs a new instance.
		/// </summary>
		public WorkingWithRepo()
		{
			// Do not delete - a parameterless constructor is required!
		}
		void ITestModule.Run()
		{
			Mouse.DefaultMoveTime = 300;
			Keyboard.DefaultKeyPressTime = 100;
			Delay.SpeedFactor = 1.0;
			
			
			// Using Ranorex.Form adapter represented by 'AUT'
			// 'AUT' is used as a folder within the repository;
			// the 'Self' property returns an object of type Ranorex.Form
			// Activates application
			repo.AUT.Self.Activate();
			// Log 'Active' state
			Report.Info(repo.AUT.Self.Active.ToString());
			// Maximize, Minimize and Restore
			repo.AUT.Self.Maximize();
					repo.AUT.Self.Minimize();
			repo.AUT.Self.Restore();
			// Closes application
			repo.AUT.Self.Close();
			
			
			// Using Ranorex.Button adapter represented by 'ButtonAdd'
			// Read and log value of 'Text' attribute
			Report.Info(repo.AUT.RxTabDataBase.BtnAddPerson.Text);
			// Press button
			repo.RxTabDataBase.BtnAddPerson.Press();
			// Read and log value of 'Enabled' attribute
			Report.Info(repo.RxTabDataBase.BtnAddPerson.Enabled.ToString());
			
			
			
			
			// Using Ranorex.RadioButton adapter
			// represented by 'GenderOption'
			// Select radio button
			repo.AUT.GenderOption.Select();
			
			
			
			
			// Accessing listitems of Ranorex.List adapter
			// represented by 'CategoryList'
			IList<ranorex.listitem> listItems = repo.DeptList.Items;
			foreach ( Ranorex.ListItem item in listItems )
			{
				Report.Info(item.Text + " is member of Department List");
			}
			
			
			
			
			// Using Ranorex.MenuItem to open 'File' menu
			repo.AUT.MenuItemFile.Select();
			
			// Selecting sub menu item 'Info'
			repo.MenuItems.Info.Select();
			
			// Read and log 'Enabled' state of menu item 'Info'
			Report.Info(repo.MenuItems.Info.Enabled.ToString());
			
					
			
			
			// Create a list of adapters using the "Info" object
			IList<ranorex.button> buttonList =
			repo.AUT.EnabledButtonsInfo.CreateAdapters<ranorex.button>();
			// Move the mouse pointer to each button of the list
			// and add a screenshot for each to the report
			foreach (Ranorex.Button button in buttonList )
			{
				button.MoveTo();
				Report.Screenshot(button);
			}
		}
    }
}
