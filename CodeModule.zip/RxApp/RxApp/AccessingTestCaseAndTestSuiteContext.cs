﻿/*
 * Created by Ranorex
 * User: alkasugandhi_ss
 * Date: 4/2/2019
 * Time: 7:36 AM
 * 
 * To change this template use Tools > Options > Coding > Edit standard headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

namespace RxApp
{
    /// <summary>
    /// Description of AccessingTestCaseAndTestSuiteContext.
    /// </summary>
    [TestModule("6F670ECB-4BAF-4FD4-9BA2-82BB8CDF6C2C", ModuleType.UserCode, 1)]
    public class AccessingTestCaseAndTestSuiteContext : ITestModule
    {
        /// <summary>
        /// Constructs a new instance.
        /// </summary>
        public AccessingTestCaseAndTestSuiteContext()
        {
            // Do not delete - a parameterless constructor is required!
        }

        /// <summary>
        /// Performs the playback of actions in this module.
        /// </summary>
        /// <remarks>You should not call this method directly, instead pass the module
        /// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
        /// that will in turn invoke this method.</remarks>
        void ITestModule.Run()
        {
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;
            
            // Click 'Save' button to open 'SaveDialog'
			repo.AUT.Buttons.ButtonSave.Click();
			
			// Read text message shown with 'SaveDialog'
			// and assign it to the variable 'varDialogTextA' bound to a test case parameter
			varDialogTextA = repo.SaveDialog.TextMessage.TextValue;
			
			
			// -------- Code Block used by User Code Action of recording B --------
			// Read value of module variable 'varDialogTextB' in other code module
			// or recording module using a user code action
			Report.Info(varDialogTextB);
			
			
			
			// Get the current data context and log
			// the current row index of a data driven run
			Report.Info(TestCase.Current.DataContext.CurrentRowIndex.ToString());
        }
    }
}
