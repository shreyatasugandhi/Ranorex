﻿/*
 * Created by Ranorex
 * User: alkasugandhi_ss
 * Date: 4/2/2019
 * Time: 7:30 AM
 * 
 * To change this template use Tools > Options > Coding > Edit standard headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

namespace RxApp
{
    /// <summary>
    /// Description of WorkingWithProperties.
    /// </summary>
    [TestModule("0E1F4A17-9C9F-438A-A43F-D9E51FC55F1E", ModuleType.UserCode, 1)]
    public class WorkingWithProperties : ITestModule
    {
        /// <summary>
        /// Constructs a new instance.
        /// </summary>
        public WorkingWithProperties()
        {
            // Do not delete - a parameterless constructor is required!
        }

        /// <summary>
        /// Performs the playback of actions in this module.
        /// </summary>
        /// <remarks>You should not call this method directly, instead pass the module
        /// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
        /// that will in turn invoke this method.</remarks>
        void ITestModule.Run()
        {
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;
            
            // Creating adapter of type 'NativeWindow' using the "...Info" object
			Ranorex.NativeWindow nativeWnd = repo.AUT.SelfInfo.CreateAdapter<ranorex.nativewindow>(false);
			
			
			// ... and read value of attribute 'ProcessName'
			Report.Info("Process name of VIP Database: " + nativeWnd.ProcessName);
			
			
			// Using Control Adapter to access properties and methods of
			// .NET WinForms control
			Ranorex.Control winFormsControl = repo.AUT.SelfInfo.CreateAdapter<ranorex.control>(false);
			
			
			// Set background color of VIP application to Color.Black using the
			// exposed property 'BackColor'
			winFormsControl.SetPropertyValue("BackColor",Color.Black);
			
			
			// Report screenshot after changing the background color
			Report.Screenshot(repo.AUT.Self);
			
			
			// Closes VIP Database by invoking the 'Close' method
			// exposed by the System.Windows.Forms.Form class
			winFormsControl.InvokeMethod("Close");
        }
    }
}
