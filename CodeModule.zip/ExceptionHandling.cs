﻿/*
 * Created by Ranorex
 * User: alkasugandhi_ss
 * Date: 4/2/2019
 * Time: 7:24 AM
 * 
 * To change this template use Tools > Options > Coding > Edit standard headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

namespace RxApp
{
    /// <summary>
    /// Description of ExceptionHandling.
    /// </summary>
    [TestModule("90EBAF6C-8BE7-4FD9-A5B0-FAB445644E7B", ModuleType.UserCode, 1)]
    public class ExceptionHandling : ITestModule
    {
        /// <summary>
        /// Constructs a new instance.
        /// </summary>
        public ExceptionHandling()
        {
            // Do not delete - a parameterless constructor is required!
        }

        /// <summary>
        /// Performs the playback of actions in this module.
        /// </summary>
        /// <remarks>You should not call this method directly, instead pass the module
        /// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
        /// that will in turn invoke this method.</remarks>
        void ITestModule.Run()
        {
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;
            
            
            Ranorex.Cell cellObject = null;
			// Try to find a cell object using two
			// different RanoreXPath expressions
			bool found = false;
			found = Host.Local.TryFindSingle<ranorex.cell>("/form//table/row/cell[3]", 2000, out cellObject);
			found = found || Host.Local.TryFindSingle<ranorex.cell>("/form//table/row/cell[4]", 2000, out cellObject);
			// If none of the expressions returns an object
			// throw new 'ElementNotFoundException' and test case fails
			if (!found)
			{
				throw new Ranorex.ElementNotFoundException("Both RanoreXPath with no return", null);
			}
			else
			{
				// If the value of attribute 'Text' does not equal to the expected value
				// throw new 'ValidationException' to break the test case
				if ( cellObject.Text == "MyExpectedTextValue" )
				{
					Report.Success("User Specific Validation","Text validation of cell object succeeded");
				}
				else
				{
					throw new Ranorex.ValidationException("Text validation of cell object failed");
				}
			}
			
			
			
			
			/////////////////////////////////////////////////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////////////////////////////////////////////
			// Failing test using validation
			
			Ranorex.Cell cellObject = null;
			// Try to find a cell object
			bool found=false;
			found = Host.Local.TryFindSingle<ranorex.cell>("/form//table/row/cell[3]", 2000, out cellObject);
			// If the expressions does not return an object
			// call Validate.Fail and the test case fails
			if (!found) Validate.Fail("RanoreXPath with no return");
			
			
			
			
			
        }
    }
}
